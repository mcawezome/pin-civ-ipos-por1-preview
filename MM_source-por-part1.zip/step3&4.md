Restructuring files structure to include classes.
Commenting code and adding docstrings
Deleting test py files and adding unit tests