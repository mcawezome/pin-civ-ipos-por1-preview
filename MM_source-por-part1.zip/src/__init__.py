import game as g

if __name__ == "__main__":
    game = g.Game(3)
    game.play()
