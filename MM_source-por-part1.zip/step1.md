
# Step 1: Review the existing code

* Comments done inline explain the code step-by-step
* TODOs are done inline which indicate which code can be modularised